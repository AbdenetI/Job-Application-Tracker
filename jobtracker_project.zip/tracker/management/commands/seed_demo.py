from django.core.management.base import BaseCommand
from django.contrib.auth import get_user_model
from tracker.models import Company, Job, Application
from django.utils import timezone

class Command(BaseCommand):
    help = 'Seed demo data'

    def handle(self, *args, **kwargs):
        User = get_user_model()
        user, _ = User.objects.get_or_create(username='demo')
        user.set_password('demo1234')
        user.save()

        acme,_ = Company.objects.get_or_create(name='Acme', website='https://acme.com')
        globex,_ = Company.objects.get_or_create(name='Globex', website='https://globex.com')

        j1,_ = Job.objects.get_or_create(company=acme, title='Software Engineer', location='Remote', source='linkedin')
        j2,_ = Job.objects.get_or_create(company=globex, title='Data Analyst', location='MN', source='company')

        Application.objects.get_or_create(user=user, company=acme, job=j1, status='applied', date_applied=timezone.localdate())
        Application.objects.get_or_create(user=user, company=globex, job=j2, status='saved')

        self.stdout.write(self.style.SUCCESS('Seeded demo data. Login with demo/demo1234'))
